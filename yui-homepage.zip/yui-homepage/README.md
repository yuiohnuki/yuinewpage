What your project is/does (and what it's called)
- This shows my basic informations about me in the main page but you can jump into another page which shows my projects for croceht and nails
Why you made your project
- I made this project because I have never made my own websites before but I wanted to organize my interests. 
How you made your project
- I made a project by using HTML, CSS
What you struggled with and what you learned
- I struggled with debugging and I learned a lot of ew commands for CSS and make it aesthetic
[![Athena Award Badge](https://img.shields.io/endpoint?url=https%3A%2F%2Faward.athena.hackclub.com%2Fapi%2Fbadge)](https://award.athena.hackclub.com?utm_source=readme)
